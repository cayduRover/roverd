plugins {
    id("com.android.application")
}

val ciBuildNumber = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 0
val roverSigningFile = rootProject.file("signing/roverd-update.p12")

android {
    namespace = "land.otter.roverd"
    compileSdk = 36

    defaultConfig {
        applicationId = "land.otter.roverd"
        minSdk = 17
        targetSdk = 36
        // Keep every CI build newer than the original versionCode=1 APK.
        versionCode = 1000 + ciBuildNumber
        versionName = "0.1.$ciBuildNumber"
        // RootEncoder 2.8.x pushes the API-17 build over the legacy 64K DEX method limit.
        // Keep the old Android floor by using the AndroidX multidex bootstrap.
        multiDexEnabled = true
    }

    signingConfigs {
        if (roverSigningFile.exists()) {
            create("roverUpdate") {
                storeFile = roverSigningFile
                storePassword = "roverd-update-key"
                keyAlias = "roverd"
                keyPassword = "roverd-update-key"
            }
        }
    }

    buildTypes {
        getByName("debug") {
            // CI decodes the permanent rover signing key before Gradle runs.
            // Local builds without that file continue to use Android's normal debug key.
            if (roverSigningFile.exists()) {
                signingConfig = signingConfigs.getByName("roverUpdate")
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("com.github.mik3y:usb-serial-for-android:3.11.0")
    implementation("com.github.jiangdongguo:AndroidUSBCamera:3.3.3")
    // 3.12.x is the final OkHttp line supporting pre-Android-5 devices.
    // Rover connections are normally plain ws:// on the local network.
    implementation("com.squareup.okhttp3:okhttp:3.12.13")

    implementation("androidx.multidex:multidex:2.0.1")

    // Camera2/MediaCodec implementation used by the API 21+ camera subsystem.
    // The root build pins all RootEncoder modules to the same current release.
    implementation("com.github.pedroSG94.RootEncoder:library:2.8.0")

    // Stable VLC Android bindings for the rover's RTSP/TCP Opus reverse-audio stream.
    // This avoids another custom RTSP/RTP/Opus decoder stack and preserves the old app floor.
    implementation("org.videolan.android:libvlc-all:3.7.5")
}
