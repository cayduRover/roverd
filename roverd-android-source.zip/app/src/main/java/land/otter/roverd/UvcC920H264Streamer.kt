package land.otter.roverd

import android.content.Context
import android.hardware.usb.UsbDevice
import android.os.Handler
import android.os.Looper
import com.jiangdg.ausbc.MultiCameraClient
import com.jiangdg.ausbc.callback.ICameraStateCallBack
import com.jiangdg.ausbc.callback.IEncodeDataCallBack
import com.jiangdg.ausbc.camera.CameraUVC
import com.jiangdg.ausbc.camera.bean.CameraRequest
import com.jiangdg.ausbc.render.env.RotateType
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean

class UvcC920H264Streamer(private val context: Context, private val config: RoverConfig, private val onRestartNeeded: (String) -> Unit = {}) {
    private val appContext = context.applicationContext
    private val closed = AtomicBoolean(false)
    private val handler = Handler(Looper.getMainLooper())
    private var client: MultiCameraClient? = null
    private var camera: MultiCameraClient.Camera? = null
    private var publisher: RtspH264Publisher? = null
    private var sps: ByteArray? = null
    private var pps: ByteArray? = null

    fun start() {
        check(!closed.get()) { "UVC streamer is closed" }
        RoverRuntimeState.setCameraPipelineState(running=false, state="Waiting for Logitech C920", cameraId=CameraDiagnostics.UVC_C920_ID, encoderName="AUSBC UVC H.264 -> roverd RTSP", width=config.cameraWidth, height=config.cameraHeight, fps=config.cameraFpsMax, bitrate=config.cameraBitrate, publishUrl=MediaUrl.videoPublishUrl(config), error="")
        val callback = object : com.jiangdg.ausbc.callback.IDeviceConnectCallBack {
            override fun onAttachDev(device: UsbDevice?) { if (isC920(device)) client?.requestPermission(device) }
            override fun onDetachDec(device: UsbDevice?) { if (isC920(device)) closeCamera() }
            override fun onConnectDev(device: UsbDevice?, ctrlBlock: com.jiangdg.usb.USBMonitor.UsbControlBlock?) { if (isC920(device) && ctrlBlock != null && !closed.get()) openCamera(device!!, ctrlBlock) }
            override fun onDisConnectDec(device: UsbDevice?, ctrlBlock: com.jiangdg.usb.USBMonitor.UsbControlBlock?) { if (isC920(device)) closeCamera() }
            override fun onCancelDev(device: UsbDevice?) { if (isC920(device)) RoverRuntimeState.setCameraPipelineState(running=false,state="USB permission denied",error="Grant USB access to Logitech C920") }
        }
        client = MultiCameraClient(appContext, callback).also { it.openDebug(false); it.register() }
        client?.getDeviceList().orEmpty().firstOrNull(::isC920)?.let { client?.requestPermission(it) } ?: RoverRuntimeState.setCameraPipelineState(running=false,state="Logitech C920 not connected",error="Connect a Logitech C920 over USB OTG")
    }

    private fun openCamera(device: UsbDevice, ctrlBlock: com.jiangdg.usb.USBMonitor.UsbControlBlock) {
        closeCamera()
        val request = CameraRequest.Builder().setPreviewWidth(config.cameraWidth.coerceAtLeast(160)).setPreviewHeight(config.cameraHeight.coerceAtLeast(120)).setRenderMode(CameraRequest.RenderMode.OPENGL).setDefaultRotateType(if (config.cameraInverted) RotateType.ANGLE_180 else RotateType.ANGLE_0).create()
        val cam = CameraUVC(appContext, device)
        cam.setUsbControlBlock(ctrlBlock)
        cam.setCameraStateCallBack(object : ICameraStateCallBack {
            override fun onCameraState(self: MultiCameraClient.Camera, code: ICameraStateCallBack.State, msg: String?) {
                when (code) {
                    ICameraStateCallBack.State.OPENED -> RoverRuntimeState.log("CAMERA UVC C920 opened ${device.deviceName}")
                    ICameraStateCallBack.State.CLOSED -> RoverRuntimeState.log("CAMERA UVC C920 closed")
                    ICameraStateCallBack.State.ERROR -> { val r=msg ?: "unknown UVC camera error"; RoverRuntimeState.log("CAMERA UVC C920 error: $r"); RoverRuntimeState.setCameraPipelineState(running=false,state="UVC camera error",error=r); onRestartNeeded(r) }
                }
            }
        })
        sps=null; pps=null; publisher?.close(); publisher=RtspH264Publisher(MediaUrl.videoPublishUrl(config))
        cam.setEncodeDataCallBack(object : IEncodeDataCallBack {
            override fun onEncodeData(type: IEncodeDataCallBack.DataType, buffer: ByteBuffer, offset: Int, size: Int, timestamp: Long) {
                if (closed.get() || size<=0) return
                val bytes=buffer.duplicate().run { position(offset.coerceAtLeast(0)); limit((offset+size).coerceAtMost(capacity())); ByteArray(remaining()).also { get(it) } }
                when(type) {
                    IEncodeDataCallBack.DataType.H264_SPS -> { val pair=H264Nals.codecParameterSets(bytes); if(pair.first!=null)sps=pair.first; if(pair.second!=null)pps=pair.second; if(sps!=null&&pps!=null)publisher?.setCodecConfig(sps!!,pps!!) }
                    IEncodeDataCallBack.DataType.H264_KEY, IEncodeDataCallBack.DataType.H264 -> { val key=type==IEncodeDataCallBack.DataType.H264_KEY; RoverRuntimeState.recordCameraEncodedFrame(bytes.size,key); publisher?.enqueue(bytes,timestamp,key) }
                    IEncodeDataCallBack.DataType.AAC -> Unit
                }
            }
        })
        camera=cam
        RoverRuntimeState.setCameraPipelineState(state="Opening Logitech C920 UVC")
        cam.openCamera(null,request); cam.captureStreamStart()
        RoverRuntimeState.setCameraPipelineState(running=true,state="Logitech C920 UVC H.264 running")
    }
    private fun closeCamera(){ camera?.let{runCatching{it.captureStreamStop()};runCatching{it.closeCamera()}};camera=null;publisher?.close();publisher=null }
    private fun isC920(d: UsbDevice?)=d!=null&&d.vendorId==0x046d&&d.productId==0x082d&&(0 until d.interfaceCount).any{i->d.getInterface(i).interfaceClass==14}
    fun close(){if(!closed.compareAndSet(false,true))return;closeCamera();client?.unRegister();client?.destroy();client=null}
}
